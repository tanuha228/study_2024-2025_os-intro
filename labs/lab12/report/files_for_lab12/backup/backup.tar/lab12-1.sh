#!/bin/bash
tar -cvf ~/backup/backup.tar lab12-1.sh
